@echo off
rem ===================================================================
rem  RUNY PRZEZNACZENIA - uruchomienie bez instalacji
rem  Otwiera gre w oknie aplikacji (Edge/Chrome) na lokalnym serwerze.
rem  Zamykajac okno serwera, konczysz gre.
rem ===================================================================
chcp 65001 >nul 2>nul
setlocal
set "HERE=%~dp0"
set "PORT=8099"

if not exist "%HERE%serve.ps1" (
  echo Brak pliku serve.ps1 obok tego skryptu.
  pause
  exit /b 1
)

echo Uruchamiam lokalny serwer gry na porcie %PORT%...
start "Arcane Spire - serwer gry (zamknij, aby zakonczyc)" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%HERE%serve.ps1" -Port %PORT% -Root "%HERE%"

timeout /t 2 /nobreak >nul
set "URL=http://127.0.0.1:%PORT%/index.html"

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=%URL% --window-size=1500,940 --no-first-run
  exit /b 0
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=%URL% --window-size=1500,940 --no-first-run
  exit /b 0
)
start "" %URL%
exit /b 0
